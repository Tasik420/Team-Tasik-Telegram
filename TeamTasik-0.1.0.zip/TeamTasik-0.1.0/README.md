<h2>Team Tasik</h2>
<p title="Team Tasik">Team Tasik is an advanced multi-featured Telegram UserBot built into Python using the Telethon.</p>

![](images/madebybangladesh.svg)
![](images/opensource.svg)
![](images/maintained.svg)
![](images/license.svg)
![](images/releasedate.svg)

<h2>String Session</h2>
<p title="String Session">Collect String Session by running python3 stringsession.py locally or generate from Replit.</p>
<a href="https://replit.com/@theridwanul/stringsession" target="_blank"><img src="images/runrepl.svg"/></a>

<h2>Deployment</h2>
<p title="Deployment">You can use Team Tasik for free with the cloud application platform Heroku.</p>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

<h2>Support</h2>
<p title="Support">You can join us on any issue related to Team Tasik Update and Support in Telegram.</p>
<a href="https://t.me/teamtasik" target="_blank"><img src="images/telegramchannelsupport.svg"/></a>
<a href="https://t.me/teamtasikofficial" target="_blank"><img src="images/telegramgroupsupport.svg"/></a>